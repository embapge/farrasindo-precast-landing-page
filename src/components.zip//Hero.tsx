import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      window.scrollTo({
        top: elementPosition - offset,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="hero" className="pt-20 bg-gradient-to-br from-blue-50 to-gray-50">
      <div className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full mb-6">
              Produsen Beton Pracetak Terpercaya
            </div>
            <h1 className="mb-6 text-gray-900">
              Solusi Beton Pracetak Berkualitas untuk Infrastruktur Modern
            </h1>
            <p className="text-gray-600 mb-8 text-lg">
              Indoprecast menyediakan produk beton pracetak berkualitas tinggi dengan standar mutu terjamin. 
              Dipercaya oleh ratusan proyek infrastruktur di seluruh Indonesia.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => scrollToSection('products')}
              >
                Lihat Produk Kami
                <ArrowRight className="ml-2" size={20} />
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => scrollToSection('contact')}
              >
                Konsultasi Gratis
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="text-green-600 flex-shrink-0 mt-1" size={24} />
                <div>
                  <div className="text-gray-900">Kualitas Terjamin</div>
                  <p className="text-gray-600 text-sm">Sesuai SNI & ISO</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="text-green-600 flex-shrink-0 mt-1" size={24} />
                <div>
                  <div className="text-gray-900">Pengiriman Cepat</div>
                  <p className="text-gray-600 text-sm">Tepat waktu</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="text-green-600 flex-shrink-0 mt-1" size={24} />
                <div>
                  <div className="text-gray-900">Harga Kompetitif</div>
                  <p className="text-gray-600 text-sm">Best value</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1583169828149-5973ebae36f5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVjYXN0JTIwY29uY3JldGUlMjBmYWN0b3J5fGVufDF8fHx8MTc2MDA4MDI0NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Indoprecast Factory"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
            
            {/* Stats Card */}
            <div className="absolute bottom-8 left-8 right-8 bg-white rounded-xl shadow-xl p-6">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-blue-600 mb-1">15+</div>
                  <p className="text-gray-600 text-sm">Tahun Pengalaman</p>
                </div>
                <div className="border-l border-r border-gray-200">
                  <div className="text-blue-600 mb-1">500+</div>
                  <p className="text-gray-600 text-sm">Proyek Selesai</p>
                </div>
                <div>
                  <div className="text-blue-600 mb-1">100+</div>
                  <p className="text-gray-600 text-sm">Mitra Terpercaya</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
