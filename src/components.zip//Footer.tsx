import { Facebook, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
import { useRouter } from '../lib/router';

export function Footer() {
  const currentYear = new Date().getFullYear();
  const { navigate } = useRouter();

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <div className="bg-yellow-500 text-white px-4 py-2 rounded inline-block mb-4">
              <span className="tracking-wider">INDOPRECAST</span>
            </div>
            <p className="text-gray-400 mb-4">
              Produsen beton pracetak terpercaya dengan standar kualitas internasional untuk mendukung pembangunan infrastruktur Indonesia.
            </p>
            <div className="mt-4 pt-4 border-t border-gray-800">
              <p className="text-sm text-gray-500 mb-2">Bagian dari</p>
              <div className="text-yellow-500 mb-2">FARRASINDO GROUP</div>
              <p className="text-sm text-gray-400">
                Solusi terintegrasi untuk kebutuhan konstruksi dan infrastruktur
              </p>
            </div>
            <div className="flex gap-4">
              <a href="#" className="bg-gray-800 p-2 rounded-lg hover:bg-yellow-500 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="bg-gray-800 p-2 rounded-lg hover:bg-yellow-500 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="bg-gray-800 p-2 rounded-lg hover:bg-yellow-500 transition-colors">
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white mb-4">Navigasi</h3>
            <ul className="space-y-2">
              <li>
                <button onClick={() => navigate('home')} className="hover:text-yellow-400 transition-colors">
                  Beranda
                </button>
              </li>
              <li>
                <button onClick={() => navigate('about')} className="hover:text-yellow-400 transition-colors">
                  Tentang Kami
                </button>
              </li>
              <li>
                <button onClick={() => navigate('products')} className="hover:text-yellow-400 transition-colors">
                  Produk
                </button>
              </li>
              <li>
                <button onClick={() => navigate('portfolio')} className="hover:text-yellow-400 transition-colors">
                  Portofolio
                </button>
              </li>
              <li>
                <button onClick={() => navigate('contact')} className="hover:text-yellow-400 transition-colors">
                  Kontak
                </button>
              </li>
            </ul>
          </div>

          {/* Products */}
          <div>
            <h3 className="text-white mb-4">Produk Utama</h3>
            <ul className="space-y-2">
              <li className="hover:text-yellow-400 transition-colors cursor-pointer">U-Ditch</li>
              <li className="hover:text-yellow-400 transition-colors cursor-pointer">Box Culvert</li>
              <li className="hover:text-yellow-400 transition-colors cursor-pointer">Paving Block</li>
              <li className="hover:text-yellow-400 transition-colors cursor-pointer">Road Barrier</li>
              <li className="hover:text-yellow-400 transition-colors cursor-pointer">Panel Lantai</li>
              <li className="hover:text-yellow-400 transition-colors cursor-pointer">Tiang Pancang</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white mb-4">Kontak</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="flex-shrink-0 mt-1" size={18} />
                <span className="text-sm">
                  Jl. Industri Raya No. 123<br />
                  Kawasan Industri MM2100<br />
                  Bekasi, Jawa Barat
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="flex-shrink-0" size={18} />
                <span className="text-sm">+62 21 1234 5678</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="flex-shrink-0" size={18} />
                <span className="text-sm">info@indoprecast.co.id</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-gray-400">
              © {currentYear} PT Indoprecast. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="hover:text-yellow-400 transition-colors">Syarat & Ketentuan</a>
              <a href="#" className="hover:text-yellow-400 transition-colors">Kebijakan Privasi</a>
              <a href="#" className="hover:text-yellow-400 transition-colors">FAQ</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
