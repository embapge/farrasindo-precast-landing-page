import { Card, CardContent } from './ui/card';

export function Clients() {
  const clientCategories = [
    {
      category: 'Kontraktor Utama',
      clients: [
        'PT Wijaya Karya (Persero) Tbk',
        'PT Adhi Karya (Persero) Tbk',
        'PT Waskita Karya (Persero) Tbk',
        'PT Pembangunan Perumahan (Persero) Tbk',
        'PT Hutama Karya (Persero)',
        'PT Nindya Karya (Persero)',
      ]
    },
    {
      category: 'Developer',
      clients: [
        'Ciputra Group',
        'Sinar Mas Land',
        'Agung Podomoro Land',
        'Summarecon Agung',
        'BSD City',
        'Lippo Group',
      ]
    },
    {
      category: 'Pemerintah & BUMN',
      clients: [
        'Kementerian PUPR',
        'Dinas Pekerjaan Umum DKI Jakarta',
        'Pemerintah Provinsi Jawa Barat',
        'Pemerintah Provinsi Jawa Tengah',
        'PT Jasa Marga (Persero) Tbk',
        'PT Perusahaan Listrik Negara (Persero)',
      ]
    },
  ];

  const testimonials = [
    {
      name: 'Ir. Bambang Suryanto',
      position: 'Project Manager',
      company: 'PT Wijaya Karya',
      text: 'Indoprecast memberikan kualitas produk yang konsisten dan pengiriman yang selalu tepat waktu. Sangat membantu kelancaran proyek kami.',
      rating: 5
    },
    {
      name: 'Drs. Ahmad Hidayat',
      position: 'Site Manager',
      company: 'PT Adhi Karya',
      text: 'Produk U-Ditch dari Indoprecast memiliki kualitas yang sangat baik dengan harga yang kompetitif. Rekomendasikan untuk proyek infrastruktur.',
      rating: 5
    },
    {
      name: 'Eng. Siti Nurhaliza, ST',
      position: 'Chief Engineer',
      company: 'Agung Podomoro Land',
      text: 'Pelayanan yang profesional dan produk berkualitas tinggi. Tim Indoprecast sangat responsif terhadap kebutuhan custom produk kami.',
      rating: 5
    },
  ];

  return (
    <section id="clients" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-yellow-100 text-yellow-700 rounded-full mb-4">
            Klien & Mitra
          </div>
          <h2 className="mb-4 text-gray-900">Dipercaya oleh Perusahaan Terkemuka</h2>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            Lebih dari 100 perusahaan konstruksi dan developer telah mempercayakan kebutuhan beton pracetak mereka kepada kami
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {clientCategories.map((category, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <h3 className="mb-4 text-yellow-600">{category.category}</h3>
                <ul className="space-y-3">
                  {category.clients.map((client, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <div className="bg-yellow-600 rounded-full w-1.5 h-1.5 mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700">{client}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Testimonials */}
        <div className="mb-12">
          <h3 className="text-center mb-8 text-gray-900">Testimoni Klien</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <svg key={i} className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 20 20">
                        <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                      </svg>
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4 italic">"{testimonial.text}"</p>
                  <div className="border-t pt-4">
                    <div className="text-gray-900">{testimonial.name}</div>
                    <p className="text-sm text-gray-600">{testimonial.position}</p>
                    <p className="text-sm text-yellow-600">{testimonial.company}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="bg-yellow-500 rounded-2xl p-8 text-white text-center">
          <h3 className="mb-6">Kenapa Mereka Memilih Indoprecast?</h3>
          <div className="grid md:grid-cols-4 gap-6">
            <div>
              <div className="text-4xl mb-2">98%</div>
              <p className="text-yellow-100">Tingkat Kepuasan Klien</p>
            </div>
            <div>
              <div className="text-4xl mb-2">95%</div>
              <p className="text-yellow-100">On-Time Delivery</p>
            </div>
            <div>
              <div className="text-4xl mb-2">100%</div>
              <p className="text-yellow-100">Quality Guarantee</p>
            </div>
            <div>
              <div className="text-4xl mb-2">24/7</div>
              <p className="text-yellow-100">Customer Support</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
