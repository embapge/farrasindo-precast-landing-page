import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Products() {
  const categories = [
    {
      id: 'drainage',
      name: 'Saluran Drainase',
      products: [
        {
          name: 'U-Ditch',
          description: 'Saluran drainase berbentuk U untuk sistem pengairan dan drainase',
          sizes: ['30x30x120', '40x40x120', '50x50x120', '60x60x120', '80x80x120', '100x100x120'],
          applications: ['Saluran air', 'Drainase jalan', 'Irigasi']
        },
        {
          name: 'Cover U-Ditch',
          description: 'Penutup untuk U-Ditch dengan berbagai pilihan beban',
          sizes: ['30x120', '40x120', '50x120', '60x120', '80x120', '100x120'],
          applications: ['Penutup saluran', 'Jalan kendaraan', 'Area pejalan kaki']
        },
        {
          name: 'Box Culvert',
          description: 'Saluran air berbentuk kotak untuk drainase dan gorong-gorong',
          sizes: ['100x100x100', '120x120x100', '150x150x100', '200x200x100'],
          applications: ['Gorong-gorong', 'Saluran bawah tanah', 'Terowongan air']
        },
      ]
    },
    {
      id: 'road',
      name: 'Produk Jalan',
      products: [
        {
          name: 'Paving Block',
          description: 'Blok beton untuk perkerasan jalan dan area pejalan kaki',
          sizes: ['Uni-grass', 'Segi enam', 'Trihex', 'Persegi panjang'],
          applications: ['Trotoar', 'Parkir', 'Taman']
        },
        {
          name: 'Road Barrier',
          description: 'Pembatas jalan untuk keamanan dan pengaturan lalu lintas',
          sizes: ['Tipe A', 'Tipe B', 'Tipe C'],
          applications: ['Pembatas jalan', 'Median', 'Pengaman']
        },
        {
          name: 'Kanstin',
          description: 'Pembatas tepi jalan dan trotoar',
          sizes: ['20x30x60', '25x40x60', '30x50x60'],
          applications: ['Tepi jalan', 'Trotoar', 'Taman']
        },
      ]
    },
    {
      id: 'building',
      name: 'Bangunan',
      products: [
        {
          name: 'Panel Lantai',
          description: 'Panel beton untuk lantai bangunan bertingkat',
          sizes: ['120x600', '120x800', '120x1000'],
          applications: ['Lantai gedung', 'Bangunan industri', 'Ruko']
        },
        {
          name: 'Tiang Pancang',
          description: 'Tiang fondasi untuk bangunan',
          sizes: ['25x25', '30x30', '35x35', '40x40'],
          applications: ['Fondasi gedung', 'Jembatan', 'Dermaga']
        },
        {
          name: 'Balok Girder',
          description: 'Balok beton prategang untuk struktur jembatan',
          sizes: ['40x60', '50x80', '60x100'],
          applications: ['Jembatan', 'Flyover', 'Struktur bentang']
        },
      ]
    },
    {
      id: 'others',
      name: 'Lainnya',
      products: [
        {
          name: 'Manhole',
          description: 'Lubang inspeksi untuk sistem drainase dan utilitas',
          sizes: ['Ø80', 'Ø100', 'Ø120', 'Ø150'],
          applications: ['Sistem drainase', 'Jaringan kabel', 'Utilitas']
        },
        {
          name: 'Grass Block',
          description: 'Blok beton berongga untuk area hijau',
          sizes: ['60x40x8', '60x40x10'],
          applications: ['Parkir hijau', 'Taman', 'Area resapan']
        },
        {
          name: 'Buis Beton',
          description: 'Pipa beton untuk gorong-gorong dan saluran air',
          sizes: ['Ø30', 'Ø40', 'Ø60', 'Ø80', 'Ø100'],
          applications: ['Gorong-gorong', 'Saluran air', 'Drainase']
        },
      ]
    },
  ];

  const [activeCategory, setActiveCategory] = useState('drainage');

  return (
    <section id="products" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full mb-4">
            Produk Kami
          </div>
          <h2 className="mb-4 text-gray-900">Katalog Produk Beton Pracetak</h2>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            Kami menyediakan berbagai macam produk beton pracetak berkualitas tinggi untuk kebutuhan infrastruktur Anda
          </p>
        </div>

        <Tabs value={activeCategory} onValueChange={setActiveCategory} className="w-full">
          <TabsList className="grid w-full max-w-4xl mx-auto grid-cols-2 lg:grid-cols-4 mb-12 h-auto">
            {categories.map((category) => (
              <TabsTrigger key={category.id} value={category.id} className="py-3">
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((category) => (
            <TabsContent key={category.id} value={category.id}>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.products.map((product, index) => (
                  <Card key={index} className="hover:shadow-xl transition-shadow">
                    <CardHeader>
                      <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg h-48 flex items-center justify-center mb-4">
                        <div className="text-white text-center">
                          <div className="mb-2">{product.name}</div>
                          <p className="text-blue-100 text-sm">Produk Berkualitas Tinggi</p>
                        </div>
                      </div>
                      <CardTitle className="text-gray-900">{product.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4">{product.description}</p>
                      
                      <div className="mb-4">
                        <div className="text-sm text-gray-700 mb-2">Ukuran tersedia (cm):</div>
                        <div className="flex flex-wrap gap-2">
                          {product.sizes.map((size, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {size}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <div className="text-sm text-gray-700 mb-2">Aplikasi:</div>
                        <div className="flex flex-wrap gap-2">
                          {product.applications.map((app, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {app}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">
            Tidak menemukan ukuran yang sesuai? Kami menerima pesanan custom sesuai kebutuhan proyek Anda.
          </p>
          <a 
            href="#contact" 
            className="text-blue-600 hover:text-blue-700 inline-flex items-center gap-2"
          >
            Hubungi kami untuk konsultasi →
          </a>
        </div>
      </div>
    </section>
  );
}
